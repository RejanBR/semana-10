package br.com.alura.farmaciaapiturma2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Farmaciaapiturma2Application {

	public static void main(String[] args) {
		SpringApplication.run(Farmaciaapiturma2Application.class, args);
	}

}
