package br.com.alura.farmaciaapiturma2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Farmaciaapiturma2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
